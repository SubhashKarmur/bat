package com.subhash;

import java.io.*;
import java.nio.file.*;
import java.util.HashMap;
import java.util.Map;

public class RemoveExtraLinesFromSpecificFolder {
    public static void main(String[] args) {
        String folderPath = "Source";
        String outputFolderPath = "Destination";

        // Create a map of keywords and their replacements
        Map<String, String> replacements = new HashMap<>();
        replacements.put("0%f-month%", "%f-month%");
        replacements.put("field=f-month", "field=f-month1");
        // Add more replacements as needed

        // Keyword to add new lines after
        String keywordForNewLine = "field=f-month1";
        String newLineToAdd = "\nThis is a new line.\n\t\tvhbvhfv\n";

        // Keywords to check and append if necessary
        String keywordToCheck = "%seconds%";
        String wordToCheckNext = "%pid%";

        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(Paths.get(folderPath), "*.icf")) {
            for (Path path : directoryStream) {
                System.out.println(path.toAbsolutePath());
                processFile(path, outputFolderPath, replacements, keywordForNewLine, newLineToAdd, keywordToCheck, wordToCheckNext);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void processFile(Path inputFilePath, String outputFolderPath, Map<String, String> replacements, String keywordForNewLine, String newLineToAdd, String keywordToCheck, String wordToCheckNext) {
        String outputFilePath = outputFolderPath + "/" + inputFilePath.getFileName().toString();

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath.toFile()));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {

            String line;
            boolean previousLineWasEmpty = false;

            while ((line = reader.readLine()) != null) {
                // Replace each keyword with its corresponding new word
                for (Map.Entry<String, String> entry : replacements.entrySet()) {
                    line = line.replace(entry.getKey(), entry.getValue());

                }

                if (line.contains(keywordToCheck) && !line.contains(wordToCheckNext)) {
                    line = line.replace(keywordToCheck, keywordToCheck+wordToCheckNext);
                }

                // Check for keyword and add new lines if found
                if (line.contains(keywordForNewLine)) {
                    writer.write(line);
                    writer.newLine();
                    writer.write(newLineToAdd);
                    writer.newLine();
                } else {
                    if (line.trim().isEmpty()) {
                        if (!previousLineWasEmpty) {
                            writer.newLine();
                        }
                        previousLineWasEmpty = true;
                    } else {
                        writer.write(line);
                        writer.newLine();
                        previousLineWasEmpty = false;
                    }
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
