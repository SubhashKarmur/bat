package com.subhash;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        try {
            // Specify the directory to search
            Path startPath = Paths.get("C:\\Users\\subha\\IdeaProjects\\SearchReplace\\json");

            // List files in the directory (non-recursive)
            try (Stream<Path> paths = Files.list(startPath)) {
                paths.filter(Files::isRegularFile)
                        .filter(path -> path.toString().endsWith(".json"))
                        .forEach(Main::processJsonFile);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void processJsonFile(Path path) {
        try {
            // Read JSON file into a string
            String content = new String(Files.readAllBytes(path));

            // Parse JSON string into JSONObject
            JSONObject jsonObject = new JSONObject(content);
            JSONArray metadataArray = jsonObject.getJSONArray("metadata");

            // Iterate through the metadata array
            for (int i = 0; i < metadataArray.length(); i++) {
                JSONObject metadata = metadataArray.getJSONObject(i);
                if (metadata.getString("name").equals("abc:inputFileName")) {
                    System.out.println( metadata.getString("value")+"\t" + path );
                    //metadata.put("value", "ipfile");
                }
            }

            // Optionally, write the modified JSON back to the file
            //Files.write(path, jsonObject.toString(2).getBytes());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
