package com.subhash;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.stream.Stream;

public class SearchReplace {

    private static String jsonFolderPath = "C:\\Users\\subha\\IdeaProjects\\SearchReplace\\json";
    private static String searchProperty = "abc:inputFileName";
    private static String searchValue = "infile";
    private static String replaceValue = "ipfile";

    public static void main(String[] args) {
        try {
            // Specify the directory to search
            Path startPath = Paths.get(jsonFolderPath);

            // List files in the directory (non-recursive)
            try (Stream<Path> paths = Files.list(startPath)) {
                paths.filter(Files::isRegularFile)
                        .filter(path -> path.toString().endsWith(".json"))
                        .forEach(SearchReplace::processJsonFile);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void processJsonFile(Path path) {
        try {
            // Read JSON file into a string
            String content = new String(Files.readAllBytes(path));

            // Parse JSON string into LinkedHashMap
            ObjectMapper mapper = new ObjectMapper();
            LinkedHashMap<String, Object> map = mapper.readValue(content, LinkedHashMap.class);

            // Create JSONObject from LinkedHashMap
            JSONObject jsonObject = new JSONObject(map);
            JSONArray metadataArray = jsonObject.getJSONArray("metadata");

            boolean searchPropertyFound = false;
            // Iterate through the metadata array
            for (int i = 0; i < metadataArray.length(); i++) {
                JSONObject metadata = metadataArray.getJSONObject(i);
                if (metadata.getString("name").equals(searchProperty)) {
                    String value = metadata.getString("value");
                    if (value.equals(replaceValue)) {
                        System.out.println("CorrectValue\t" + value + "\t" + path.getFileName() + "\t" + path);
                    } else if (value.equals(searchValue)) {
                        System.out.println("IncorrectValue\t" + value + "\t" + path.getFileName() + "\t" + path);
                        metadata.put("value", replaceValue);
                        // Optionally, write the modified JSON back to the file
                        /*Files.write(path, jsonObject.toString(2).getBytes());
                        System.out.println("ReplacedValue\t" + replaceValue + "\t" + path.getFileName() + "\t" + path);*/
                    } else {
                        System.out.println("UnknownValue\t" + value + "\t" + path.getFileName() + "\t" + path);
                    }
                    searchPropertyFound = true;
                    break;
                }
            }
            if (!searchPropertyFound) {
                System.out.println("NotFound\t" + searchProperty + "\t" + path.getFileName() + "\t" + path);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
